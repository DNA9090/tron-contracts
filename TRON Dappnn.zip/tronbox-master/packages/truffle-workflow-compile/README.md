# truffle-workflow-compile
Core workflow logic for the `truffle compile` command behavior
