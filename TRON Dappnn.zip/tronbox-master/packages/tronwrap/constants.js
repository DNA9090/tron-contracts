module.exports = {

  deployParameters: {
    feeLimit: 1e9,
    userFeePercentage: 100,
    originEnergyLimit: 1e7,
    callValue: 0,
    tokenValue: undefined,
    tokenId: undefined
  }

}
