
module.exports = {
  preReleaseCompilerWarning: "This is a pre-release compiler version, please do not use it in production."
}
