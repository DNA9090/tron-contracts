{{ABSTRACTION}}

var BINARIES = {{BINARIES}};

module.exports = contract.clone(BINARIES);
