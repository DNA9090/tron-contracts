# truffle-resolver
Resolve contract dependencies given multiple configurable dependency sources
