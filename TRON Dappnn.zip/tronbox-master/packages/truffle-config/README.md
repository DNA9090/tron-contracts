# truffle-config
Utility for interacting with truffle.js files
