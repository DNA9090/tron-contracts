var Debugger = require("./lib/debugger").default;

module.exports = Debugger;

