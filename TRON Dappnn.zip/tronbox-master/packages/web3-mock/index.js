
module.exports = require('./lib/web3mock');
