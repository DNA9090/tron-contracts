# web3-mock
Allows you to test web3 dApps without a live web3 connection
