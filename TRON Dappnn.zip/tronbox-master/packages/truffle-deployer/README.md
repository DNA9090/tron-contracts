# truffle-deployer
Light deployment module for deploying Ethereum contracts

This package is in the process of being moved to its own module (here). For documentation, see the `deployer` section within the [Truffle migration documentation](http://truffleframework.com/docs/getting_started/migrations).

# Testing

```
$ npm test
```
