#!/usr/bin/env bash

(
cd packages/tronbox
yarn run prepare
)
